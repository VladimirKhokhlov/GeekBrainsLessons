package lesson7.string;

public class StringTest {
    public static void main(String[] args) {
        String str = "Hello ";
        str += "World!";
        System.out.println(str);
    }
}
