package lesson5;

public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello, World!");
        int a = 5;
//        String str = "sdgds";
        String str = new String("sdgds");

//        Integer b = 5;
        Integer b = new Integer(5);
    }

}
