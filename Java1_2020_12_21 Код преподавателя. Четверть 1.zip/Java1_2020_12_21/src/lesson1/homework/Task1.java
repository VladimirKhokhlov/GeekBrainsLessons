package lesson1.homework;

public class Task1 {

    public static void main(String[] args) {
        System.out.println("Task 1!");
    }
}
