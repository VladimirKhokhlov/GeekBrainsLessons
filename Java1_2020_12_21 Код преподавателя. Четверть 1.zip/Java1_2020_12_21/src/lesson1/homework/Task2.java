package lesson1.homework;

public class Task2 {

    public static void main(String[] args) {
        byte a = -128;
        System.out.println(a);

        short b = Short.MAX_VALUE;
        System.out.println(b);

        int c = Integer.MIN_VALUE;
        System.out.println(c);

        long d = 1_000_000L;
        System.out.println(d);

        float e = 3.14f;
        System.out.println(e);

        long f = Long.MAX_VALUE;
        System.out.println(f);

        char g = '@';
        System.out.println(g);

        boolean h = true;
        System.out.println(h);

        String str = "simple text";
        System.out.println(str);

    }
}
