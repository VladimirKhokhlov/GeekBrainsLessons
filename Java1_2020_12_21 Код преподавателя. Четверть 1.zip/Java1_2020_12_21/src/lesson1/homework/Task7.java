package lesson1.homework;

public class Task7 {

    public static void main(String[] args) {
        greeting("GeekBrains");
    }

    private static void greeting(String name) {
        System.out.println("Hello, " + name + "!");
    }
}
