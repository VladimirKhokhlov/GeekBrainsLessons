package lesson3;

public class Examples {

    public static void main(String[] args) {
        int a = -5;
        if (a > 5) {
            System.out.println("+");
        }
        System.out.println("-");
    }
}
