package lesson6;

public class CatType1 /*extends Cat*/ {

    public CatType1(String name, int age, String color) {
//        super(name, age, color);
    }
}
